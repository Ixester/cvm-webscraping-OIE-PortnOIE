import json
import pandas as pd

def store_output(kpis, json_path, csv_path):
    # Save as JSON
    with open(json_path, "w") as f:
        json.dump(kpis, f, indent=4)

    # Save as CSV
    df = pd.DataFrame(kpis)
    df.to_csv(csv_path, index=False)
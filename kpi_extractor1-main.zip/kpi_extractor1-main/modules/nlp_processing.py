from transformers import pipeline, AutoTokenizer, AutoModelForTokenClassification
import spacy

def process_nlp(text, config):
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(config["tokenizer_name"])

    # Ensure the input is a string
    if not isinstance(text, str):
        raise ValueError("Input text must be a string.")

    # Tokenize and truncate the text to 512 tokens
    inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)

    # Load NER model
    model = AutoModelForTokenClassification.from_pretrained(config["tokenizer_name"])

    # Load NER pipeline
    ner_pipeline = pipeline(
        "ner",
        model=model,
        tokenizer=tokenizer,
        device=0,  # Use GPU if available
        framework="pt",  # Use PyTorch
        num_workers=0,  # Disable multiprocessing
    )

    # Process text with Transformers
    ner_results = ner_pipeline(text)  # Pass the raw text here

    # Process text with spaCy
    nlp = spacy.load(config["decoder_params"]["ner_model"])
    doc = nlp(text)
    entities = [(ent.text, ent.label_) for ent in doc.ents]
    relations = []  # Placeholder for relation extraction

    return entities, relations
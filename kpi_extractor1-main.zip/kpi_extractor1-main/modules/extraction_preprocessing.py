import PyPDF2
import tabula
import re

def extract_and_preprocess(pdf_path):
    # Extract text using PyPDF2
    text = ""
    with open(pdf_path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:  # Ensure text is not None
                text += page_text + "\n"

    # Clean text
    text = re.sub(r"\s+", " ", text)  # Remove extra spaces
    text = text.lower()  # Normalize case

    # Extract tables using tabula
    tables = tabula.read_pdf(pdf_path, pages="all", multiple_tables=True)

    # Debug: Print extracted text and tables
    print("Extracted Text Sample:", text[:500])  # Print first 500 characters
    print("Extracted Tables:", tables)

    return text, tables
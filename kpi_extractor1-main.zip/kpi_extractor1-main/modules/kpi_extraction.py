import re

def extract_kpis(entities, relations, tables, config):
    kpis = []
    # Example: Extract KPIs using keywords
    keywords = ["lucro líquido", "receita", "despesas"]
    for entity, label in entities:
        if label == "KPI":
            for keyword in keywords:
                if keyword in entity.lower():
                    kpis.append({"kpi": keyword, "value": entity})
    return kpis
import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"
import yaml
from modules.extraction_preprocessing import extract_and_preprocess
from modules.nlp_processing import process_nlp
from modules.kpi_extraction import extract_kpis
from modules.storage_output import store_output

# Load configuration
try:
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
except Exception as e:
    print(f"Error loading config.yaml: {e}")
    exit()

# Step 1: Extract and preprocess
pdf_path = "/Users/italoxesteres/Downloads/021016000101013-3.pdf"
try:
    clean_text, tables = extract_and_preprocess(pdf_path)
except Exception as e:
    print(f"Error extracting and preprocessing PDF: {e}")
    exit()

# Step 2: NLP processing
try:
    entities, relations = process_nlp(clean_text, config)
except Exception as e:
    print(f"Error processing NLP: {e}")
    exit()

# Step 3: KPI extraction
try:
    kpis = extract_kpis(entities, relations, tables, config)
except Exception as e:
    print(f"Error extracting KPIs: {e}")
    exit()

# Step 4: Store output
try:
    store_output(kpis, "output/kpis.json", "output/kpis.csv")
    print("KPI extraction completed successfully! Check the output folder.")
except Exception as e:
    print(f"Error storing output: {e}")
    exit()
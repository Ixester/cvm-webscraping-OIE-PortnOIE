# KPI Extractor for Portuguese Reports

This project extracts KPIs from Portuguese financial reports using NLP and PDF processing.

## Features
- PDF text extraction using PyPDF2 and tabula.
- NLP processing using spaCy and Hugging Face Transformers.
- KPI extraction using custom rules and regex.

## Installation
```bash
pip install -r requirements.txt
